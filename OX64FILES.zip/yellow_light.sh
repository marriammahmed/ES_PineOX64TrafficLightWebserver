#!/bin/bash
# Turn ON YELLOW light (GPIO 20) and OFF others
sudo gpioset gpiochip0 32=0 20=1 27=0

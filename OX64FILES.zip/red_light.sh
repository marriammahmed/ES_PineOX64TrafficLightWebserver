#!/bin/bash
# Turn ON RED light (GPIO 32) and OFF others
sudo gpioset gpiochip0 32=1 20=0 27=0


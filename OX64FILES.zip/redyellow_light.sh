#!/bin/sh

sudo gpioset gpiochip0 32=1 20=1 27=0

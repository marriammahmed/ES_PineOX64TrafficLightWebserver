#!/bin/sh
# Turn ON GREEN light (GPIO 27) and OFF others
sudo gpioset gpiochip0 32=0 20=0 27=1


#!/bin/sh
sudo gpioset gpiochip0 32=0 20=0 27=0  
